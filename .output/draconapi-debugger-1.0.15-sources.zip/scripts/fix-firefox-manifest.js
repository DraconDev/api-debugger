#!/usr/bin/env node
/**
 * Post-zip script to fix Firefox manifest
 * Patches the ZIP file directly to add data_collection_permissions
 */

import AdmZip from "adm-zip";
import { existsSync } from "fs";

const FIREFOX_ZIP = ".output/draconapi-debugger-1.1.0-firefox.zip";

if (!existsSync(FIREFOX_ZIP)) {
  console.log(`Firefox zip not found: ${FIREFOX_ZIP}, skipping fix`);
  process.exit(0);
}

const zip = new AdmZip(FIREFOX_ZIP);
const manifestEntry = zip.getEntry("manifest.json");

if (!manifestEntry) {
  console.error("manifest.json not found in zip!");
  process.exit(1);
}

const manifest = JSON.parse(manifestEntry.getData().toString("utf-8"));

if (!manifest.browser_specific_settings) {
  manifest.browser_specific_settings = {};
}
if (!manifest.browser_specific_settings.gecko) {
  manifest.browser_specific_settings.gecko = {};
}
manifest.browser_specific_settings.gecko.data_collection_permissions = false;

zip.updateFile("manifest.json", Buffer.from(JSON.stringify(manifest, null, 2)));
zip.writeZip(FIREFOX_ZIP);

console.log(
  "Fixed Firefox manifest: added data_collection_permissions = false",
);
