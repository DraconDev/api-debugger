# Release Checklist

## Pre-Release

### Version & Metadata

- [ ] Update version number in `package.json` (currently 0.1.726+)
- [x] Store listing description ready (`docs/STORE_LISTING.md`)
- [x] Manifest description updated ("No account. No cloud. No spying.")
- [x] Build verified for Chrome (chrome-mv3)
- [x] Build verified for Firefox (firefox-mv2)

### Legal & Documentation

- [ ] Create LICENSE file (MIT - mentioned in README but file missing)
- [ ] Create CHANGELOG.md
- [ ] Privacy Policy URL (needed for stores)
- [ ] Terms of Service URL (optional)

### Store Assets

- [ ] Screenshots for Chrome Web Store (1920x1080 or similar)
- [ ] Promotional image / store banner
- [ ] Video walkthrough (optional but recommended)
- [ ] Verify icon looks good at all sizes (16, 32, 48, 96, 128)

### Chrome Web Store

- [ ] Developer account set up (chrome://chrome-webstore/)
- [ ] Upload ZIP: `.output/chrome-mv3.zip`
- [ ] Add screenshots
- [ ] Add description
- [ ] Set category: "Developer Tools"
- [ ] Set pricing: "Free"
- [ ] Mark as "Stable" when ready

### Firefox Add-ons

- [ ] Mozilla Add-ons developer account
- [ ] Upload `.output/firefox-mv2.zip`
- [ ] Review takes ~1-3 days
- [ ] Add AMO description

### Microsoft Edge Add-ons

- [ ] Dev center account at https://partner.microsoft.com/
- [ ] Upload extension package
- [ ] Usually auto-approved for Chromium-based

### GitHub Release

- [ ] Create git tag (e.g., v0.2.0)
- [ ] Write release notes
- [ ] Attach pre-built ZIPs
- [ ] Attach source code

## Post-Release

### Verification

- [ ] Extension loads in Chrome without errors
- [ ] Extension loads in Firefox without errors
- [ ] Extension loads in Edge without errors
- [ ] Basic functionality tested manually
- [ ] Request capture works
- [ ] Request building works
- [ ] Settings save works

### Monitoring

- [ ] Watch for crash reports
- [ ] Monitor store reviews
- [ ] Set up error tracking (optional - Sentry?)

## Optional / Nice to Have

### AI Marketplace Listings

- [ ] OpenRouter featured models listing
- [ ] Consider if there's an AI plugins marketplace

### Distribution

- [ ] Consider homebrew package
- [ ] Consider snap store
- [ ] Consider flatpak

---

## Current Status

**Builds:**

- Chrome: ✅ Working
- Firefox: ✅ Working
- Edge: Need to test

**Documentation:**

- README: ✅ Updated
- Store listing: ✅ Created
- LICENSE: ❌ Missing (says MIT in README but no file)
- CHANGELOG: ❌ Missing

**Version:** 0.1.726+ (in package.json)

**Tests:** 956 passing
